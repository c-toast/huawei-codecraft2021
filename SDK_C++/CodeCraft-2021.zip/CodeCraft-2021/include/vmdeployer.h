//
// Created by ctoast on 2021/3/24.
//

#ifndef HUAWEI_CODECRAFT_VMDEPLOYER_H
#define HUAWEI_CODECRAFT_VMDEPLOYER_H

#include <vector>
#include "vm.h"

class VMDeployer{
public:
    int deployVMNum=0;

    int migrateAndDeploy(std::vector<VMObj*> &unhandledVMObj);

    int migrate(std::vector<VMObj*> &unhandledVMObj);

    int Deploy(std::vector<VMObj*> &unhandledVMObj);
};

#endif //HUAWEI_CODECRAFT_VMDEPLOYER_H
