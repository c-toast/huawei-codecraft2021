//
// Created by ctoast on 2021/3/24.
//

#ifndef HUAWEI_CODECRAFT_VMMIGRATER_H
#define HUAWEI_CODECRAFT_VMMIGRATER_H


class vmmigrater {

};


#endif //HUAWEI_CODECRAFT_VMMIGRATER_H
